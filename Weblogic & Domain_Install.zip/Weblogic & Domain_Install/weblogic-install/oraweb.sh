export MW_HOME=/u01/app/oracle/middleware
export WLS_HOME=$MW_HOME/wlserver
export WL_HOME=$WLS_HOME
# Set to the appropriate JAVA_HOME.
export JAVA_HOME=/u01/app/oracle/jdk1.8.0_241
export PATH=$JAVA_HOME/bin:$PATH
