place oraweb.sh on path /etc/profile.d/
untar jdk on path /u01/app/oracle
place oraInst.loc on path /u01/software/
place respective response file on /u01/software/